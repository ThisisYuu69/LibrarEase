-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Nov 21, 2024 at 01:33 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_book`
--

CREATE TABLE `add_book` (
  `id` int(5) NOT NULL,
  `book_name` varchar(50) NOT NULL,
  `book_image` varchar(500) NOT NULL,
  `author_name` varchar(50) NOT NULL,
  `publication` varchar(50) NOT NULL,
  `purchase_date` date NOT NULL,
  `price` int(100) NOT NULL,
  `quality` varchar(50) NOT NULL,
  `book_total` int(100) NOT NULL,
  `available_quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_book`
--

INSERT INTO `add_book` (`id`, `book_name`, `book_image`, `author_name`, `publication`, `purchase_date`, `price`, `quality`, `book_total`, `available_quantity`) VALUES
(1, 'To Kill a Mocking Bird', 'book_image/547b622d97add4f62739605819ad2651To_Kill_a_Mockingbird_(first_edition_cover).png', 'Harper Lee', 'J.B Lippincott & Co.', '2024-01-15', 850, 'Excellent (Hardcover)', 10, 9),
(2, '1984', 'book_image/da2cca093dcba56c3da439138418d1b21984.png', 'George Orwell', 'Secker & Warburg', '2024-02-05', 600, 'Very Good (Paperback)', 10, 9),
(3, 'Sapiens: A Brief History of Humankind', 'book_image/d5e98c9dc4f76bc8d512b40a8bbe5b28sapiens.png', 'Yuval Noah Harari', 'Harper', '2024-03-10', 1200, 'Excellent (Hardcover)', 10, 10),
(4, 'The Great Gatsby', 'book_image/a227529f5555472151c73fef156f2850the_great_gatsby.png', 'F. Scott Fitzgerald', 'Charles Scribner\'s Sons', '2024-04-18', 450, 'Good (Paperback)', 10, 10),
(5, 'Atomic Habits', 'book_image/f1645eb0e8b3a657152b0b3ff2be063datomic-habits.png', 'James Clear', 'Avery', '2024-05-07', 950, 'Very Good (Hardcover)', 10, 10),
(6, 'Pride and Prejudice', 'book_image/682d312e73ddf233fb355b6cf7b2a8d7pride_&_prejudice.png', 'Jane Austen', 'T. Egerton', '2024-06-22', 800, 'Excellent (Hardcover)', 10, 10),
(7, 'Becoming', 'book_image/472a15faef8d4a793ae54e56c540a432becoming.png', 'Michelle Obama', 'Crown Publishing Group', '2024-07-15', 1100, 'Excellent (Hardcover)', 10, 10),
(8, 'The Catcher in the Rye', 'book_image/309fa8e893a2bb1f4fd4f36393b6e217The-Catcher-in-the-rye.png', 'J.D Salinger', 'Little, Brown and Company', '2024-08-01', 550, 'Good (Paperback)', 10, 10),
(10, 'The Alchemist', 'book_image/eeda92f8a8dc1cdf75354e18393b3aafThe-alchemist.png', 'Paulo Coelho', 'HarperOne', '2024-10-01', 880, 'Excellent (Hardcover)', 10, 10),
(11, 'The Subtle Art of Not Giving a F*ck', 'book_image/cee7329d727fb9588ae43b0b2e43526cthe-subtle-art-of-not-giving-a-f-ck.png', 'Mark Manson', 'HarperOne', '2024-09-10', 750, 'Very Good (Paperback)', 0, 10),
(12, 'The Silent Patience', 'book_image/b94c709ad9eea9ba57718bb44e686e2ethe-silent-patience.png', 'Alex Michaelides', 'Celadon Books', '2024-11-21', 850, 'Excellent', 10, 8);

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `login_ID` int(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `id` int(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`login_ID`, `email`, `password`, `id`) VALUES
(1, 'jerald', 'jerald123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `issue_book`
--

CREATE TABLE `issue_book` (
  `id` bigint(5) NOT NULL,
  `student_id` int(5) DEFAULT NULL,
  `studentname` varchar(50) NOT NULL,
  `birthdate` date NOT NULL,
  `phonenumber` bigint(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `book_name` text NOT NULL,
  `issue_date` date NOT NULL,
  `return_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `issue_book`
--

INSERT INTO `issue_book` (`id`, `student_id`, `studentname`, `birthdate`, `phonenumber`, `email`, `book_name`, `issue_date`, `return_date`) VALUES
(1, 2, 'Jason De Erit', '2024-11-19', 9876543219, 'jason@gmail.com', 'To Kill a Mocking Bird', '2024-11-20', '2024-11-20'),
(2, 2, 'Jason De Erit', '2024-11-19', 9876543219, 'jason@gmail.com', 'The Alchemist', '2024-11-20', '2024-11-20'),
(3, 2, 'Jason De Erit', '2024-11-19', 9876543219, 'jason@gmail.com', 'To Kill a Mocking Bird', '2024-11-21', '2024-11-21'),
(4, 3, 'Kenneth Gado', '2024-11-19', 9876543210, 'gado@gmail.com', 'To Kill a Mocking Bird', '2024-11-21', '0000-00-00'),
(5, 2, 'Jason De Erit', '2024-11-19', 9876543219, 'jason@gmail.com', '1984', '2024-11-21', '0000-00-00'),
(6, 2, 'Jason De Erit', '2024-11-19', 9876543219, 'jason@gmail.com', 'The Silent Patience', '2024-11-21', '0000-00-00'),
(7, 4, 'CJ Bacolod', '2024-11-21', 6391231231231, 'cj@gmail.com', 'The Silent Patience', '2024-11-21', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `message_tbl`
--

CREATE TABLE `message_tbl` (
  `id` int(5) NOT NULL,
  `susername` varchar(50) NOT NULL,
  `dusername` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `msg` varchar(500) NOT NULL,
  `read_msg` varchar(10) NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `message_tbl`
--

INSERT INTO `message_tbl` (`id`, `susername`, `dusername`, `title`, `msg`, `read_msg`, `time`) VALUES
(1, 'jerald', '2', 'Overdue Date', 'please return the book immediately!', 'y', '19:55:00'),
(2, 'jerald', '2', 'Hoy!', 'higvhvhv', 'y', '20:31:00');

-- --------------------------------------------------------

--
-- Table structure for table `reqmain_tbl`
--

CREATE TABLE `reqmain_tbl` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `vehicletype` varchar(100) NOT NULL,
  `reqnum` int(99) NOT NULL,
  `datereq` varchar(100) NOT NULL,
  `description` varchar(99) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reqmain_tbl`
--

INSERT INTO `reqmain_tbl` (`id`, `name`, `vehicletype`, `reqnum`, `datereq`, `description`) VALUES
(1, 'Ellis, Jerald Glenn R.', 'SUV', 0, '2024-05-30', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `student_registration`
--

CREATE TABLE `student_registration` (
  `id` int(11) NOT NULL,
  `studentname` text NOT NULL,
  `birthdate` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `phonenumber` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_registration`
--

INSERT INTO `student_registration` (`id`, `studentname`, `birthdate`, `gender`, `phonenumber`, `email`, `password`) VALUES
(1, 'admin1', '2024-11-19', 'Male', '+639565988743', 'admin1@gmail.com', 'admin'),
(2, 'Jason De Erit', '2024-11-19', 'Male', '09876543219', 'jason@gmail.com', '111'),
(3, 'Kenneth Gado', '2024-11-19', 'Male', '09876543210', 'gado@gmail.com', '222'),
(4, 'CJ Bacolod', '2024-11-21', 'Male', '+6391231231231', 'cj@gmail.com', '333');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_book`
--
ALTER TABLE `add_book`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`login_ID`);

--
-- Indexes for table `issue_book`
--
ALTER TABLE `issue_book`
  ADD PRIMARY KEY (`id`) USING BTREE;

--
-- Indexes for table `message_tbl`
--
ALTER TABLE `message_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reqmain_tbl`
--
ALTER TABLE `reqmain_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_registration`
--
ALTER TABLE `student_registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_book`
--
ALTER TABLE `add_book`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `login_ID` int(225) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `issue_book`
--
ALTER TABLE `issue_book`
  MODIFY `id` bigint(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `message_tbl`
--
ALTER TABLE `message_tbl`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `reqmain_tbl`
--
ALTER TABLE `reqmain_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student_registration`
--
ALTER TABLE `student_registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
